﻿// R.1: Manage resources automatically using resource handles and RAII (Resource Acquisition Is Initialization)
// R.10: Avoid malloc() and free()
// R.11: Avoid calling new and delete explicitly
// R.20: Use unique_ptr or shared_ptr to represent ownership
// R.21 : Prefer unique_ptr over shared_ptr unless you need to share ownership
// R.22 : Use make_shared() to make shared_ptrs
// R.23 : Use make_unique() to make unique_ptrs
// ES.60 : Avoid new and delete outside resource management functions
// ES.61 : Delete arrays using delete[] and non - arrays using delete
