#include <memory>

int main()
{
	std::default_delete<int> p;
}