
void f1(int n)
{
	int local = n;
}

void f2(const int& n)
{
	int local = n;
}

int main()
{
	int n = 10;

	bad(n);
	good(n);
}