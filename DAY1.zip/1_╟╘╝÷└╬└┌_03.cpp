#include <iostream>
#include <string>

// std::string �� �б⸸ �ϴ� ���

void f1(std::string s)
{
}

void f2(std::string s)
{
}

int main()
{
	std::string s = "to be or not to be";

}