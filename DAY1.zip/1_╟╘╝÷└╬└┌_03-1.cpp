#include <iostream>
#include <string>
#include <string_view>

int main()
{
	std::string s = "to be or not to be";

	std::string      ss = s;
	std::string_view sv = s;
}