#include <iostream>
#include <string_view>
#include <string>
#include <array>

class Person
{
	std::string name;
	std::string address;
	std::array<int, 32> data;
public:
	void print_msg(const std::string& msg)
	{
		std::cout << msg << std::endl;
	}
	void set_data(const std::array<int, 32>& d)
	{
		data = d;
	}
};

int main()
{
	Person p;

	std::string s = "to be or no to be";
	std::array<int, 32> arr = { 0 };

	p.print_msg(s);
	p.set_data(arr);
}