#include <iostream>
#include <string>

class Person
{
	std::string name;
public:
	void set_name(const std::string& n) { name = n; }
};

int main()
{
	Person p;

	std::string s = "lee";
	p.set_name(s);

}