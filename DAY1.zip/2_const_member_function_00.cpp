// Con.1 : By default, make objects immutable
// Con.2 : By default, make member functions const
// Con.3 : By default, pass pointers and references to consts

int main()
{
	int max = 10; // �б⸸ �ϴ� �������

	int score[max];
}