class Point
{
	int x, y;
public:
	Point(int a, int b) : x(a), y(b) {  }
};

int main()
{
	Point p1(1, 2); // ok

	Point p2; // ??
}