#include <iostream>

class Test
{
	int value;
public:
	Test(int value) : value(value) {}

	void f1() 
	{
		int* p = &value;
	}
};

int main()
{
	Test t(10);
	t.f1();
}


