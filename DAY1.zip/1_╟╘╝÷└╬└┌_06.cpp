int add_sub(int a, int b)
{
	int s = a + b;

	return s;
}

int main()
{
	int s = add_sub(1, 2);
}