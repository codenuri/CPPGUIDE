
// F.53: Avoid capturing by reference in lambdas 
//       that will be used non - locally, 
//       including returned, stored on the heap, or passed to another thread

#include <vector>
#include <functional>
#include <vector>

std::function<int(int, int)> f; 

void foo()
{
	int num = 10;
	f = [&num](int a, int b) { return a + b + num; };

}	

void goo()
{
	int ret = f(1, 2); 
}



int main()
{
	foo();
	goo();

	// 1. ���� ǥ������ ��� ���
	auto f1 = [](int a, int b) { return a + b; };
}