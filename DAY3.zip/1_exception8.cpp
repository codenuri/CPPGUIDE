#include <iostream>
#include <mutex>
#include <thread>

// CP.20: Use RAII, never plain lock() / unlock()

std::mutex m;

void foo()
{
	m.lock();
	throw std::runtime_error("my exception");
	m.unlock();
}

int main()
{
	std::thread t1(foo);
	std::thread t2(foo);

	t1.join();
	t2.join();
}