// F.6  : If your function must not throw, declare it noexcept


// noexcept
#include <iostream>

void f1() {}
void f2() {}

int main()
{
	bool b1 = noexcept(f1());
	bool b2 = noexcept(f2());
}