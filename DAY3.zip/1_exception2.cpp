#include <iostream>
#include <string>

struct Resource
{
	Resource()  { std::cout << "Resource()" << std::endl; }
	~Resource() { std::cout << "~Resource()" << std::endl; }
};

class Test
{
	Resource* res;
public:
	Test() : res(new Resource)
	{
	}
	~Test()
	{
		delete res;
	}
};
int main()
{
	Test t;
}