// C.42: If a constructor cannot construct a valid object, throw an exception
#include <iostream>

class FileStream
{
	FILE* file;
public:
	FileStream(const std::string& name)
	{
		// name �� ���� ���� �ʴ´ٸ� ?
	}
};

int main()
{

}
