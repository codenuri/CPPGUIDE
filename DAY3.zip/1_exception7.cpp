#include <iostream>

// C.36 : A destructor must not fail
// C.37 : Make destructors noexcept

class Object
{
public:
	~Object() { std::cout << "~Object()\n"; }
};

void foo()
{
	Object obj;
	throw std::runtime_error("my exception");
}

int main()
{
	try
	{
		foo();
	}
	catch (...)
	{
	}
}