﻿// R.11: Avoid calling new and delete explicitly
// R.1: Manage resources automatically using resource handles and RAII (Resource Acquisition Is Initialization)
// E.6: Use RAII to prevent leaks

#include <iostream>
#include <memory>

int main()
{
	int* p = new int;				

	std::shared_ptr<int> sp1(p);	
									
	std::shared_ptr<int> sp2 = sp1; 

	std::shared_ptr<int> sp3(p); // ???

}
